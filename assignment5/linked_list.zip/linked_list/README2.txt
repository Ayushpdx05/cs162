Hello, welcome to the 2nd part of assignment 5 dear Ian Dugo!

README2.TXT

Ayush singh 
934361230

Description:
This program is about a linked list which is a data structure. 
Linked list contains an entry to the next node and a data item. 
This is just a fancy array. Our program is meant to implement functions which will add, remove and sort through a linked list using certain techniques and algorithms.

Instructions:
The first step would be to compile. You can do that by going to the terminal and typing in make and once the program has compiled
(compilation in layman terms is just making it so the code can be executed by the computer aka the computer will be able to understand what we are writing). 
After compilation we choose to execute the file which means we have to go to the terminal and type ./link_list.
 After that we have officially started the program. Once begun we have to press enter to complete the tasks which have already been coded in the program and we should be able to see the tasks being completed successfully. 

Limitations:
The program does not account for error handling so a limitation would be that the user enters anything except enter.

For each of the following function, explain the algorithm you used and the Big O for runtime complexity 
a. sort_ascending() 
I used the merge sort algorithm. The total big O for sort ascending is O(nlogn). 

b. sort_descending() 
I used a version of selection sort. The total big O for sort descending should be O(n^2)

c. count_prime()
I used a algorithm which checks if the value is divisible by any number up to its square root. The big O should be O(sqr n).
