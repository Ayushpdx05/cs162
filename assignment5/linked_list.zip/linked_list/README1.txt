README1.TXT

Ayush singh 
934361230

Description:
This is a program where we use a technique called recursion to print out a pattern. 
Recursion is just a function which calls on itself.
 For our particular program we use this technique to print out an “X” pattern with “*” and indented space as a way to represent the X.

Instructions:
The first step would be to compile. 
You can do that by going to the terminal and typing in make and once the program has compiled (compilation in layman terms is just making it so the code can be executed by the computer aka the computer will be able to understand what we are writing). 
After compilation we choose to execute the fractal file by running the common ./fractal in the terminal.
After this we have officially started the program and we are prompted to enter the value of N this represents the amount of lines the cross has on each side.
After that we are prompted for the column number which represents the amount of leading white space the pattern has. 

Limitations:
The program does not account for error handling so a limitation would be that the user enters a non valid integer which would cause the program to produce unexpected results.